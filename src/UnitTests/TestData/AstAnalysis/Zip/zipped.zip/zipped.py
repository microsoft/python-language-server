class Zip:
    a: int = 5
    def test(self) -> int:
        pass

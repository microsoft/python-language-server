from b import X

h = X()
y = h.test()

class A:
    a: int
    def test(self) -> int:
        pass

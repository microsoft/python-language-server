

class X:
    def test(self):
        return 5

def test(a: int) -> str:
    pass

hello: float

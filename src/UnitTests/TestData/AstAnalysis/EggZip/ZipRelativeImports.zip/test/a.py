from subfolder.b import X
from subfolder.c import h, x, i, s

# h should be a float
# i should be an int
# s should be a string



from .b import X, hello

# Should be a float
h = hello

x = X()
# Should be an int
i = x.test()

# Should be a string
s = x.test1()



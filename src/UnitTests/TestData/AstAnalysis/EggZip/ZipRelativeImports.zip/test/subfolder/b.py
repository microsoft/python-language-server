class X:
    def test(self) -> int:
        return 5

    def test1(self) -> str:
        return "str"

hello: float = 1.0
